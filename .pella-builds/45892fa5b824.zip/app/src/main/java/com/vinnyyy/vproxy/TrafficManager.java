package com.vinnyyy.vproxy;

import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * In-memory + persistent traffic history manager.
 * Bounded to avoid unbounded growth on low-RAM devices.
 */
public class TrafficManager {
    private static final String TAG = "TrafficManager";
    private static final String FILE_NAME = "traffic_log.json";
    private static final int MAX_ENTRIES = 500;

    private static TrafficManager instance;
    private final List<TrafficEntry> sessionData = new ArrayList<>();
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final List<Listener> listeners = new ArrayList<>();

    public interface Listener {
        void onTrafficUpdated();
    }

    public static synchronized TrafficManager getInstance() {
        if (instance == null) {
            instance = new TrafficManager();
        }
        return instance;
    }

    private TrafficManager() {}

    public synchronized void addListener(Listener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public synchronized void removeListener(Listener l) {
        listeners.remove(l);
    }

    private void notifyListeners() {
        for (Listener l : new ArrayList<>(listeners)) {
            try { l.onTrafficUpdated(); } catch (Exception ignored) {}
        }
    }

    public synchronized void addEntry(TrafficEntry entry) {
        sessionData.add(0, entry);
        while (sessionData.size() > MAX_ENTRIES) {
            sessionData.remove(sessionData.size() - 1);
        }
        notifyListeners();
        persistAsync();
    }

    public synchronized List<TrafficEntry> getSessionData() {
        return new ArrayList<>(sessionData);
    }

    public synchronized TrafficEntry getEntry(int index) {
        if (index >= 0 && index < sessionData.size()) {
            return sessionData.get(index);
        }
        return null;
    }

    public synchronized TrafficEntry getEntryById(String id) {
        for (TrafficEntry e : sessionData) {
            if (e.id.equals(id)) return e;
        }
        return null;
    }

    public synchronized void clearAll() {
        sessionData.clear();
        notifyListeners();
        persistAsync();
    }

    public synchronized int size() {
        return sessionData.size();
    }

    private void persistAsync() {
        final ArrayList<TrafficEntry> snapshot = new ArrayList<>(sessionData);
        ioExecutor.execute(() -> writeToDisk(snapshot));
    }

    private void writeToDisk(List<TrafficEntry> list) {
        try {
            File filesDir = VProxyApplication.getAppContext() != null
                    ? VProxyApplication.getAppContext().getFilesDir() : null;
            if (filesDir == null) return;
            File tmp = new File(filesDir, FILE_NAME + ".tmp");
            File target = new File(filesDir, FILE_NAME);
            JSONArray arr = new JSONArray();
            for (TrafficEntry e : list) {
                JSONObject o = new JSONObject();
                o.put("id", e.id);
                o.put("timestamp", e.timestamp);
                o.put("method", e.method);
                o.put("uri", e.uri);
                o.put("statusCode", e.statusCode);
                o.put("reqHeaders", e.reqHeaders);
                o.put("reqBody", Base64.encodeToString(e.reqBody, Base64.NO_WRAP));
                o.put("respHeaders", e.respHeaders);
                o.put("respBody", Base64.encodeToString(e.respBody, Base64.NO_WRAP));
                o.put("hostname", e.hostname);
                arr.put(o);
            }
            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                fos.write(arr.toString().getBytes(StandardCharsets.UTF_8));
            }
            if (!tmp.renameTo(target)) {
                // fallback
                try (FileOutputStream fos = new FileOutputStream(target)) {
                    fos.write(arr.toString().getBytes(StandardCharsets.UTF_8));
                }
                tmp.delete();
            }
        } catch (Exception e) {
            Log.e(TAG, "persist failed", e);
        }
    }

    public void loadFromDisk() {
        ioExecutor.execute(() -> {
            try {
                File filesDir = VProxyApplication.getAppContext() != null
                        ? VProxyApplication.getAppContext().getFilesDir() : null;
                if (filesDir == null) return;
                File f = new File(filesDir, FILE_NAME);
                if (!f.exists()) return;
                byte[] data;
                try (FileInputStream fis = new FileInputStream(f)) {
                    data = new byte[(int) f.length()];
                    int read = fis.read(data);
                    if (read <= 0) return;
                }
                JSONArray arr = new JSONArray(new String(data, StandardCharsets.UTF_8));
                List<TrafficEntry> loaded = new ArrayList<>();
                for (int i = 0; i < arr.length() && loaded.size() < MAX_ENTRIES; i++) {
                    JSONObject o = arr.getJSONObject(i);
                    byte[] reqB = Base64.decode(o.optString("reqBody", ""), Base64.NO_WRAP);
                    byte[] respB = Base64.decode(o.optString("respBody", ""), Base64.NO_WRAP);
                    TrafficEntry e = new TrafficEntry(
                            o.optString("method"),
                            o.optString("uri"),
                            o.optInt("statusCode"),
                            o.optString("reqHeaders"),
                            reqB,
                            o.optString("respHeaders"),
                            respB
                    );
                    loaded.add(e);
                }
                synchronized (this) {
                    sessionData.clear();
                    sessionData.addAll(loaded);
                }
                notifyListeners();
            } catch (Exception e) {
                Log.e(TAG, "load failed", e);
            }
        });
    }
}

package com.vinnyyy.vproxy;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Connection Details");
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        String id = getIntent().getStringExtra("entry_id");
        TrafficEntry e = id != null ? TrafficManager.getInstance().getEntryById(id) : null;
        TextView tv = findViewById(R.id.tv_detail);
        if (e == null) {
            tv.setText("Entry not found");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Method: ").append(e.method).append("\n");
        sb.append("URI: ").append(e.uri).append("\n");
        sb.append("Status: ").append(e.statusCode).append("\n");
        sb.append("Host: ").append(e.hostname).append("\n");
        sb.append("Time: ").append(e.getFormattedTime()).append("\n");
        sb.append("Req size: ").append(e.requestSize).append(" B\n");
        sb.append("Resp size: ").append(e.responseSize).append(" B\n\n");
        sb.append("--- Request Headers ---\n").append(e.reqHeaders).append("\n");
        sb.append("--- Response Headers ---\n").append(e.respHeaders).append("\n");
        if (e.reqBody.length > 0 && e.reqBody.length < 8192) {
            sb.append("--- Request Body (text) ---\n");
            sb.append(new String(e.reqBody)).append("\n");
        }
        if (e.respBody.length > 0 && e.respBody.length < 8192) {
            sb.append("--- Response Body (text) ---\n");
            sb.append(new String(e.respBody)).append("\n");
        }
        tv.setText(sb.toString());
    }
}

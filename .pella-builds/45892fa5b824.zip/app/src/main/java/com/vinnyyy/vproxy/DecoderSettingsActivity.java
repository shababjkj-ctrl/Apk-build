package com.vinnyyy.vproxy;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

public class DecoderSettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail); // reuse simple layout
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Decoder Settings");
        }
        toolbar.setNavigationOnClickListener(v -> finish());
        findViewById(R.id.tv_detail).setVisibility(android.view.View.VISIBLE);
        ((android.widget.TextView) findViewById(R.id.tv_detail))
                .setText("Decoder settings preserved from original package.\n\nProtocol parsers are read-only and do not modify traffic.");
    }
}

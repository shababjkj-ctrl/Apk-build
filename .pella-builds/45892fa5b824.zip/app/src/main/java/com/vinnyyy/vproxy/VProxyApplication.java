package com.vinnyyy.vproxy;

import android.app.Application;
import android.content.Context;

public class VProxyApplication extends Application {
    private static Context appContext;

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = getApplicationContext();
        TrafficManager.getInstance().loadFromDisk();
    }

    public static Context getAppContext() {
        return appContext;
    }
}

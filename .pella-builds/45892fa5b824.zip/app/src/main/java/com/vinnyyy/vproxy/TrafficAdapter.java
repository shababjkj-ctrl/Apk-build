package com.vinnyyy.vproxy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TrafficAdapter extends RecyclerView.Adapter<TrafficAdapter.VH> {

    public interface OnClick {
        void onClick(TrafficEntry entry);
    }

    private final List<TrafficEntry> items = new ArrayList<>();
    private final OnClick onClick;

    public TrafficAdapter(OnClick onClick) {
        this.onClick = onClick;
    }

    public void submit(List<TrafficEntry> data) {
        items.clear();
        if (data != null) items.addAll(data);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_traffic, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        TrafficEntry e = items.get(position);
        h.tvMethod.setText(e.method);
        h.tvUri.setText(e.uri);
        h.tvMeta.setText(e.getFormattedTime() + "  ·  " + e.statusCode + "  ·  " + e.hostname);
        int color = e.statusCode >= 400
                ? R.color.status_stopped
                : (e.statusCode >= 300 ? R.color.status_warning : R.color.status_running);
        h.tvMethod.setTextColor(ContextCompat.getColor(h.itemView.getContext(), color));
        h.itemView.setOnClickListener(v -> onClick.onClick(e));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvMethod, tvUri, tvMeta;
        VH(View v) {
            super(v);
            tvMethod = v.findViewById(R.id.tv_method);
            tvUri = v.findViewById(R.id.tv_uri);
            tvMeta = v.findViewById(R.id.tv_meta);
        }
    }
}

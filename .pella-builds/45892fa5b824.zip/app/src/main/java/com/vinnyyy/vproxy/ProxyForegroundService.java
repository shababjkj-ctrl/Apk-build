package com.vinnyyy.vproxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

/**
 * Foreground service that hosts the local ProxyServer.
 */
public class ProxyForegroundService extends Service implements ProxyServer.ProxyListener {
    private static final String TAG = "ProxyFgService";
    private static final String CHANNEL_ID = "mohasin_proxy_channel";
    private static final int NOTIF_ID = 1001;

    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_FORWARD = "forward_url";
    public static final String ACTION_STOP = "com.vinnyyy.vproxy.STOP_PROXY";

    private final IBinder binder = new LocalBinder();
    private ProxyServer proxyServer;
    private boolean running = false;
    private int currentPort = 8080;
    private String forwardUrl = "";
    private Callback callback;

    public interface Callback {
        void onStatusChanged(boolean running, int port);
        void onTraffic(TrafficEntry entry);
    }

    public class LocalBinder extends Binder {
        public ProxyForegroundService getService() {
            return ProxyForegroundService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopProxy();
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences prefs = getSharedPreferences("proxy_prefs", MODE_PRIVATE);
        currentPort = intent != null ? intent.getIntExtra(EXTRA_PORT, prefs.getInt("port", 8080))
                : prefs.getInt("port", 8080);
        forwardUrl = intent != null ? intent.getStringExtra(EXTRA_FORWARD)
                : prefs.getString("forward_url", "");
        if (forwardUrl == null) forwardUrl = prefs.getString("forward_url", "");

        startProxy(currentPort, forwardUrl);
        return START_STICKY;
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
        if (cb != null) {
            cb.onStatusChanged(running, currentPort);
        }
    }

    public boolean isRunning() {
        return running;
    }

    public int getPort() {
        return currentPort;
    }

    public String getForwardUrl() {
        return forwardUrl;
    }

    public synchronized void startProxy(int port, String url) {
        if (running) {
            stopProxy();
        }
        try {
            currentPort = port;
            forwardUrl = url != null ? url : "";
            proxyServer = new ProxyServer(port, forwardUrl, this);
            proxyServer.start(fi.iki.elonen.NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            running = true;
            startForeground(NOTIF_ID, buildNotification());
            if (callback != null) callback.onStatusChanged(true, port);
            Log.i(TAG, "Proxy started on port " + port);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start proxy", e);
            running = false;
            if (callback != null) callback.onStatusChanged(false, port);
        }
    }

    public synchronized void stopProxy() {
        if (proxyServer != null) {
            try {
                proxyServer.stop();
            } catch (Exception ignored) {}
            proxyServer = null;
        }
        running = false;
        stopForeground(true);
        if (callback != null) callback.onStatusChanged(false, currentPort);
        Log.i(TAG, "Proxy stopped");
    }

    public void updateForwardUrl(String url) {
        forwardUrl = url != null ? url : "";
        if (proxyServer != null) {
            proxyServer.setForwardUrl(forwardUrl);
        }
        getSharedPreferences("proxy_prefs", MODE_PRIVATE)
                .edit().putString("forward_url", forwardUrl).apply();
    }

    @Override
    public void onTrafficCaptured(TrafficEntry entry) {
        TrafficManager.getInstance().addEntry(entry);
        if (callback != null) {
            callback.onTraffic(entry);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, ProxyForegroundService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_text, currentPort))
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentIntent(pi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription("MOHASIN PROXY foreground service");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onDestroy() {
        stopProxy();
        super.onDestroy();
    }
}

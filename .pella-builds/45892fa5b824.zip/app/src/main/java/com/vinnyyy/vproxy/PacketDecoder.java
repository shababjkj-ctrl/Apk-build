package com.vinnyyy.vproxy;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Read-only packet decoder for common network protocols.
 * Validates basic boundaries; does not mutate input.
 */
public class PacketDecoder {

    public static class Field {
        public final String name;
        public final String value;
        public final int offset;
        public final int length;

        public Field(String name, String value, int offset, int length) {
            this.name = name;
            this.value = value;
            this.offset = offset;
            this.length = length;
        }
    }

    public static class ParseResult {
        public final boolean success;
        public final String protocol;
        public final String summary;
        public final List<Field> fields;
        public final String error;

        public ParseResult(boolean success, String protocol, String summary, List<Field> fields, String error) {
            this.success = success;
            this.protocol = protocol;
            this.summary = summary;
            this.fields = fields != null ? fields : new ArrayList<>();
            this.error = error;
        }
    }

    public static ParseResult decode(byte[] data) {
        if (data == null || data.length == 0) {
            return new ParseResult(false, "NONE", "", null, "Empty input");
        }
        // Try HTTP first (text)
        if (looksLikeHttp(data)) {
            return decodeHttp(data);
        }
        // IPv4
        if (data.length >= 20 && (data[0] >> 4 & 0xF) == 4) {
            return decodeIPv4(data);
        }
        // IPv6
        if (data.length >= 40 && (data[0] >> 4 & 0xF) == 6) {
            return decodeIPv6(data);
        }
        // DNS (heuristic on port would be external; try header)
        if (data.length >= 12) {
            ParseResult dns = tryDns(data);
            if (dns.success) return dns;
        }
        // TLS ClientHello heuristic
        if (data.length >= 5 && (data[0] & 0xFF) == 0x16) {
            return decodeTls(data);
        }
        return new ParseResult(false, "UNKNOWN", "Unrecognized format (" + data.length + " bytes)",
                hexDumpFields(data, Math.min(64, data.length)), "Could not identify protocol");
    }

    private static boolean looksLikeHttp(byte[] data) {
        String s = new String(data, 0, Math.min(data.length, 16), StandardCharsets.US_ASCII).toUpperCase(Locale.US);
        return s.startsWith("GET ") || s.startsWith("POST ") || s.startsWith("PUT ") ||
                s.startsWith("HEAD ") || s.startsWith("HTTP/") || s.startsWith("CONNECT ") ||
                s.startsWith("OPTIONS ") || s.startsWith("DELETE ") || s.startsWith("PATCH ");
    }

    private static ParseResult decodeHttp(byte[] data) {
        List<Field> fields = new ArrayList<>();
        String text = new String(data, StandardCharsets.ISO_8859_1);
        String[] lines = text.split("\r\n|\n", 50);
        if (lines.length == 0) {
            return new ParseResult(false, "HTTP", "", null, "Malformed HTTP");
        }
        fields.add(new Field("Request/Status Line", lines[0], 0, lines[0].length()));
        int offset = lines[0].length() + 2;
        for (int i = 1; i < lines.length; i++) {
            if (lines[i].isEmpty()) break;
            fields.add(new Field("Header", lines[i], offset, lines[i].length()));
            offset += lines[i].length() + 2;
        }
        return new ParseResult(true, "HTTP", lines[0], fields, null);
    }

    private static ParseResult decodeIPv4(byte[] data) {
        if (data.length < 20) {
            return new ParseResult(false, "IPv4", "", null, "Packet too short for IPv4 header");
        }
        List<Field> fields = new ArrayList<>();
        int version = (data[0] >> 4) & 0xF;
        int ihl = (data[0] & 0x0F) * 4;
        if (ihl < 20 || data.length < ihl) {
            return new ParseResult(false, "IPv4", "", null, "Invalid IHL or truncated header");
        }
        int totalLen = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
        int protocol = data[9] & 0xFF;
        String src = String.format(Locale.US, "%d.%d.%d.%d", data[12]&0xFF, data[13]&0xFF, data[14]&0xFF, data[15]&0xFF);
        String dst = String.format(Locale.US, "%d.%d.%d.%d", data[16]&0xFF, data[17]&0xFF, data[18]&0xFF, data[19]&0xFF);

        fields.add(new Field("Version", String.valueOf(version), 0, 1));
        fields.add(new Field("IHL", ihl + " bytes", 0, 1));
        fields.add(new Field("Total Length", String.valueOf(totalLen), 2, 2));
        fields.add(new Field("Protocol", protocolName(protocol) + " (" + protocol + ")", 9, 1));
        fields.add(new Field("Source IP", src, 12, 4));
        fields.add(new Field("Destination IP", dst, 16, 4));

        String summary = "IPv4 " + src + " → " + dst + " proto=" + protocolName(protocol);
        // Nested TCP/UDP
        if (protocol == 6 && data.length >= ihl + 20) {
            ParseResult tcp = decodeTcp(data, ihl);
            fields.addAll(tcp.fields);
            summary += " | " + tcp.summary;
        } else if (protocol == 17 && data.length >= ihl + 8) {
            ParseResult udp = decodeUdp(data, ihl);
            fields.addAll(udp.fields);
            summary += " | " + udp.summary;
        }
        return new ParseResult(true, "IPv4", summary, fields, null);
    }

    private static ParseResult decodeIPv6(byte[] data) {
        if (data.length < 40) {
            return new ParseResult(false, "IPv6", "", null, "Packet too short for IPv6 header");
        }
        List<Field> fields = new ArrayList<>();
        int nextHeader = data[6] & 0xFF;
        String src = formatIPv6(data, 8);
        String dst = formatIPv6(data, 24);
        fields.add(new Field("Version", "6", 0, 1));
        fields.add(new Field("Next Header", protocolName(nextHeader) + " (" + nextHeader + ")", 6, 1));
        fields.add(new Field("Source", src, 8, 16));
        fields.add(new Field("Destination", dst, 24, 16));
        String summary = "IPv6 " + src + " → " + dst;
        return new ParseResult(true, "IPv6", summary, fields, null);
    }

    private static ParseResult decodeTcp(byte[] data, int offset) {
        List<Field> fields = new ArrayList<>();
        if (data.length < offset + 20) {
            return new ParseResult(false, "TCP", "", fields, "Truncated TCP");
        }
        int srcPort = ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
        int dstPort = ((data[offset + 2] & 0xFF) << 8) | (data[offset + 3] & 0xFF);
        long seq = ((long) (data[offset + 4] & 0xFF) << 24) | ((data[offset + 5] & 0xFF) << 16)
                | ((data[offset + 6] & 0xFF) << 8) | (data[offset + 7] & 0xFF);
        int flags = data[offset + 13] & 0xFF;
        fields.add(new Field("TCP Src Port", String.valueOf(srcPort), offset, 2));
        fields.add(new Field("TCP Dst Port", String.valueOf(dstPort), offset + 2, 2));
        fields.add(new Field("TCP Seq", String.valueOf(seq), offset + 4, 4));
        fields.add(new Field("TCP Flags", flagsToString(flags), offset + 13, 1));
        return new ParseResult(true, "TCP", "TCP " + srcPort + " → " + dstPort + " [" + flagsToString(flags) + "]", fields, null);
    }

    private static ParseResult decodeUdp(byte[] data, int offset) {
        List<Field> fields = new ArrayList<>();
        int srcPort = ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
        int dstPort = ((data[offset + 2] & 0xFF) << 8) | (data[offset + 3] & 0xFF);
        int len = ((data[offset + 4] & 0xFF) << 8) | (data[offset + 5] & 0xFF);
        fields.add(new Field("UDP Src Port", String.valueOf(srcPort), offset, 2));
        fields.add(new Field("UDP Dst Port", String.valueOf(dstPort), offset + 2, 2));
        fields.add(new Field("UDP Length", String.valueOf(len), offset + 4, 2));
        return new ParseResult(true, "UDP", "UDP " + srcPort + " → " + dstPort, fields, null);
    }

    private static ParseResult tryDns(byte[] data) {
        // Very basic: transaction ID + flags
        int flags = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
        int qdcount = ((data[4] & 0xFF) << 8) | (data[5] & 0xFF);
        if (qdcount > 20) return new ParseResult(false, "DNS", "", null, null);
        List<Field> fields = new ArrayList<>();
        fields.add(new Field("Transaction ID", String.format("%04X", ((data[0]&0xFF)<<8)|(data[1]&0xFF)), 0, 2));
        fields.add(new Field("Flags", String.format("%04X", flags), 2, 2));
        fields.add(new Field("Questions", String.valueOf(qdcount), 4, 2));
        boolean qr = (flags & 0x8000) != 0;
        return new ParseResult(true, "DNS", (qr ? "DNS Response" : "DNS Query") + " qd=" + qdcount, fields, null);
    }

    private static ParseResult decodeTls(byte[] data) {
        List<Field> fields = new ArrayList<>();
        int contentType = data[0] & 0xFF;
        int version = ((data[1] & 0xFF) << 8) | (data[2] & 0xFF);
        int length = ((data[3] & 0xFF) << 8) | (data[4] & 0xFF);
        fields.add(new Field("Content Type", tlsContentType(contentType), 0, 1));
        fields.add(new Field("Version", String.format("0x%04X", version), 1, 2));
        fields.add(new Field("Length", String.valueOf(length), 3, 2));
        String summary = "TLS " + tlsContentType(contentType) + " ver=" + String.format("%04X", version);
        return new ParseResult(true, "TLS", summary, fields, null);
    }

    private static List<Field> hexDumpFields(byte[] data, int max) {
        List<Field> f = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < max; i++) {
            sb.append(String.format("%02X ", data[i] & 0xFF));
            if ((i + 1) % 16 == 0) sb.append("\n");
        }
        f.add(new Field("Hex dump", sb.toString().trim(), 0, max));
        return f;
    }

    private static String protocolName(int p) {
        switch (p) {
            case 1: return "ICMP";
            case 6: return "TCP";
            case 17: return "UDP";
            case 58: return "ICMPv6";
            default: return "Proto";
        }
    }

    private static String flagsToString(int flags) {
        StringBuilder sb = new StringBuilder();
        if ((flags & 0x01) != 0) sb.append("FIN ");
        if ((flags & 0x02) != 0) sb.append("SYN ");
        if ((flags & 0x04) != 0) sb.append("RST ");
        if ((flags & 0x08) != 0) sb.append("PSH ");
        if ((flags & 0x10) != 0) sb.append("ACK ");
        if ((flags & 0x20) != 0) sb.append("URG ");
        return sb.length() == 0 ? "-" : sb.toString().trim();
    }

    private static String tlsContentType(int t) {
        switch (t) {
            case 20: return "ChangeCipherSpec";
            case 21: return "Alert";
            case 22: return "Handshake";
            case 23: return "ApplicationData";
            default: return "Type " + t;
        }
    }

    private static String formatIPv6(byte[] data, int off) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i > 0) sb.append(":");
            int v = ((data[off + i * 2] & 0xFF) << 8) | (data[off + i * 2 + 1] & 0xFF);
            sb.append(String.format("%x", v));
        }
        return sb.toString();
    }

    /** Decode hex string input (common for decoder UI). */
    public static byte[] hexToBytes(String hex) {
        String cleaned = hex.replaceAll("\\s|0x|,", "");
        if (cleaned.length() % 2 != 0) cleaned = "0" + cleaned;
        byte[] out = new byte[cleaned.length() / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (byte) Integer.parseInt(cleaned.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }
}

package com.vinnyyy.vproxy;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.appbar.MaterialToolbar;

/**
 * Placeholder for original EditActivity (image/data editing features from assets).
 * Original logic involved complex view scaling and asset data; reconstructed as informational screen.
 */
public class EditActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Edit");
        }
        toolbar.setNavigationOnClickListener(v -> finish());
        ((android.widget.TextView) findViewById(R.id.tv_detail))
                .setText("Edit Activity (reconstructed stub).\n\nOriginal application contained additional editing workflows tied to assets/data.json. Core proxy and traffic features are fully functional in MainActivity.");
    }
}

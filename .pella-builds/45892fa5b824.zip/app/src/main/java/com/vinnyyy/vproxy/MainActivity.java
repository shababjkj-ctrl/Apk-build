package com.vinnyyy.vproxy;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ProxyForegroundService.Callback, TrafficManager.Listener {

    private static final int REQ_NOTIFICATION = 100;
    private static final int REQ_CREATE_JSON = 201;
    private static final int REQ_CREATE_CSV = 202;
    private static final int REQ_CREATE_CONFIG = 203;

    private ProxyForegroundService proxyService;
    private boolean bound = false;
    private SharedPreferences prefs;

    private TextView tvStatus, tvPortInfo, tvForwardUrl, tvStats, tvDecodeResult;
    private EditText etTargetUrl, etPort, etDecoderInput, etSearch;
    private MaterialButton btnStartStop;
    private RecyclerView rvTraffic;
    private TrafficAdapter adapter;

    private View pageDashboard, pageTraffic, pageDecoder, pageSettings, pageExport, pageAbout;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            proxyService = ((ProxyForegroundService.LocalBinder) service).getService();
            proxyService.setCallback(MainActivity.this);
            bound = true;
            refreshStatusUi();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
            proxyService = null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("proxy_prefs", MODE_PRIVATE);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        bindViews();
        setupNavigation();
        setupTrafficList();
        setupButtons();

        etTargetUrl.setText(prefs.getString("forward_url", ""));
        etPort.setText(String.valueOf(prefs.getInt("port", 8080)));
        tvForwardUrl.setText("Forward URL: " + (prefs.getString("forward_url", "").isEmpty() ? "Not Set" : prefs.getString("forward_url", "")));

        requestNotificationPermission();
        TrafficManager.getInstance().addListener(this);
        updateStats();
    }

    private void bindViews() {
        pageDashboard = findViewById(R.id.page_dashboard);
        pageTraffic = findViewById(R.id.page_traffic);
        pageDecoder = findViewById(R.id.page_decoder);
        pageSettings = findViewById(R.id.page_settings);
        pageExport = findViewById(R.id.page_export);
        pageAbout = findViewById(R.id.page_about);

        tvStatus = findViewById(R.id.tv_status);
        tvPortInfo = findViewById(R.id.tv_port_info);
        tvForwardUrl = findViewById(R.id.tv_forward_url);
        tvStats = findViewById(R.id.tv_stats);
        tvDecodeResult = findViewById(R.id.tv_decode_result);
        etTargetUrl = findViewById(R.id.et_target_url);
        etPort = findViewById(R.id.et_port);
        etDecoderInput = findViewById(R.id.et_decoder_input);
        etSearch = findViewById(R.id.et_search);
        btnStartStop = findViewById(R.id.btn_start_stop);
        rvTraffic = findViewById(R.id.rv_traffic);
    }

    private void setupNavigation() {
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            showPage(id);
            return true;
        });
        showPage(R.id.nav_dashboard);
    }

    private void showPage(int navId) {
        pageDashboard.setVisibility(View.GONE);
        pageTraffic.setVisibility(View.GONE);
        pageDecoder.setVisibility(View.GONE);
        pageSettings.setVisibility(View.GONE);
        pageExport.setVisibility(View.GONE);
        pageAbout.setVisibility(View.GONE);

        if (navId == R.id.nav_dashboard) pageDashboard.setVisibility(View.VISIBLE);
        else if (navId == R.id.nav_traffic) {
            pageTraffic.setVisibility(View.VISIBLE);
            refreshTrafficList();
        } else if (navId == R.id.nav_decoder) pageDecoder.setVisibility(View.VISIBLE);
        else if (navId == R.id.nav_settings) pageSettings.setVisibility(View.VISIBLE);
        else if (navId == R.id.nav_export) pageExport.setVisibility(View.VISIBLE);
        else if (navId == R.id.nav_about) pageAbout.setVisibility(View.VISIBLE);
    }

    private void setupTrafficList() {
        adapter = new TrafficAdapter(entry -> {
            Intent i = new Intent(this, DetailActivity.class);
            i.putExtra("entry_id", entry.id);
            startActivity(i);
        });
        rvTraffic.setLayoutManager(new LinearLayoutManager(this));
        rvTraffic.setAdapter(adapter);
        etSearch.addTextChangedListener(new SimpleTextWatcher(s -> refreshTrafficList()));
    }

    private void setupButtons() {
        btnStartStop.setOnClickListener(v -> toggleProxy());
        findViewById(R.id.btn_save_url).setOnClickListener(v -> saveForwardUrl());
        findViewById(R.id.btn_save_settings).setOnClickListener(v -> saveSettings());
        findViewById(R.id.btn_clear_traffic).setOnClickListener(v -> {
            TrafficManager.getInstance().clearAll();
            DatabaseManager.getInstance(this).clear();
            refreshTrafficList();
            updateStats();
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btn_decode).setOnClickListener(v -> runDecoder());
        findViewById(R.id.btn_paste).setOnClickListener(v -> pasteToDecoder());
        findViewById(R.id.btn_export_json).setOnClickListener(v -> startExport("application/json", "mohasin_traffic.json", REQ_CREATE_JSON));
        findViewById(R.id.btn_export_csv).setOnClickListener(v -> startExport("text/csv", "mohasin_traffic.csv", REQ_CREATE_CSV));
        findViewById(R.id.btn_export_config).setOnClickListener(v -> startExport("application/json", "localconfig.json", REQ_CREATE_CONFIG));
        findViewById(R.id.btn_contact).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_url))));
            } catch (Exception e) {
                Toast.makeText(this, "Cannot open Telegram", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void toggleProxy() {
        if (bound && proxyService != null && proxyService.isRunning()) {
            proxyService.stopProxy();
            Intent stop = new Intent(this, ProxyForegroundService.class);
            stop.setAction(ProxyForegroundService.ACTION_STOP);
            startService(stop);
        } else {
            int port = 8080;
            try {
                port = Integer.parseInt(etPort.getText().toString().trim());
            } catch (Exception ignored) {}
            String url = etTargetUrl.getText().toString().trim();
            Intent i = new Intent(this, ProxyForegroundService.class);
            i.putExtra(ProxyForegroundService.EXTRA_PORT, port);
            i.putExtra(ProxyForegroundService.EXTRA_FORWARD, url);
            ContextCompat.startForegroundService(this, i);
            bindService(i, connection, Context.BIND_AUTO_CREATE);
        }
        refreshStatusUi();
    }

    private void saveForwardUrl() {
        String url = etTargetUrl.getText().toString().trim();
        prefs.edit().putString("forward_url", url).apply();
        tvForwardUrl.setText("Forward URL: " + (url.isEmpty() ? "Not Set" : url));
        if (bound && proxyService != null) {
            proxyService.updateForwardUrl(url);
        }
        Toast.makeText(this, "URL saved", Toast.LENGTH_SHORT).show();
    }

    private void saveSettings() {
        int port = 8080;
        try {
            port = Integer.parseInt(etPort.getText().toString().trim());
            if (port < 1024 || port > 65535) throw new IllegalArgumentException();
        } catch (Exception e) {
            Toast.makeText(this, "Invalid port (use 1024-65535)", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putInt("port", port).apply();
        tvPortInfo.setText("Port: " + port);
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private void runDecoder() {
        String input = etDecoderInput.getText().toString().trim();
        if (input.isEmpty()) {
            tvDecodeResult.setText("Empty input");
            return;
        }
        byte[] data;
        try {
            if (input.matches("(?i)^[0-9a-f\\s,x]+$") && input.replaceAll("[^0-9a-fA-F]", "").length() >= 4) {
                data = PacketDecoder.hexToBytes(input);
            } else {
                data = input.getBytes(StandardCharsets.ISO_8859_1);
            }
            PacketDecoder.ParseResult r = PacketDecoder.decode(data);
            StringBuilder sb = new StringBuilder();
            sb.append(r.success ? "✓ " : "✗ ").append(r.protocol).append("\n");
            sb.append(r.summary).append("\n\n");
            if (r.error != null) sb.append("Note: ").append(r.error).append("\n\n");
            for (PacketDecoder.Field f : r.fields) {
                sb.append(f.name).append(": ").append(f.value).append("\n");
            }
            tvDecodeResult.setText(sb.toString());
        } catch (Exception e) {
            tvDecodeResult.setText("Decode error: " + e.getMessage());
        }
    }

    private void pasteToDecoder() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip()) {
            ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
            if (item != null && item.getText() != null) {
                etDecoderInput.setText(item.getText());
            }
        }
    }

    private void startExport(String mime, String name, int code) {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(intent, code);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) return;
            if (requestCode == REQ_CREATE_JSON) {
                os.write(buildJsonExport().getBytes(StandardCharsets.UTF_8));
            } else if (requestCode == REQ_CREATE_CSV) {
                os.write(buildCsvExport().getBytes(StandardCharsets.UTF_8));
            } else if (requestCode == REQ_CREATE_CONFIG) {
                JSONObject cfg = new JSONObject();
                cfg.put("proxy_port", prefs.getInt("port", 8080));
                cfg.put("forward_url", prefs.getString("forward_url", ""));
                cfg.put("app", "MOHASIN PROXY");
                os.write(cfg.toString(2).getBytes(StandardCharsets.UTF_8));
            }
            Toast.makeText(this, "Exported successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String buildJsonExport() throws Exception {
        JSONArray arr = new JSONArray();
        for (TrafficEntry e : TrafficManager.getInstance().getSessionData()) {
            JSONObject o = new JSONObject();
            o.put("id", e.id);
            o.put("timestamp", e.timestamp);
            o.put("method", e.method);
            o.put("uri", e.uri);
            o.put("statusCode", e.statusCode);
            o.put("hostname", e.hostname);
            o.put("reqHeaders", e.reqHeaders);
            o.put("respHeaders", e.respHeaders);
            o.put("requestSize", e.requestSize);
            o.put("responseSize", e.responseSize);
            arr.put(o);
        }
        return arr.toString(2);
    }

    private String buildCsvExport() {
        StringBuilder sb = new StringBuilder();
        sb.append("timestamp,method,uri,status,hostname,req_size,resp_size\n");
        for (TrafficEntry e : TrafficManager.getInstance().getSessionData()) {
            sb.append(e.timestamp).append(',')
                    .append(csv(e.method)).append(',')
                    .append(csv(e.uri)).append(',')
                    .append(e.statusCode).append(',')
                    .append(csv(e.hostname)).append(',')
                    .append(e.requestSize).append(',')
                    .append(e.responseSize).append('\n');
        }
        return sb.toString();
    }

    private static String csv(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private void refreshStatusUi() {
        runOnUiThread(() -> {
            boolean running = bound && proxyService != null && proxyService.isRunning();
            int port = prefs.getInt("port", 8080);
            if (bound && proxyService != null) port = proxyService.getPort();
            tvStatus.setText(running ? "Status: RUNNING" : "Status: STOPPED");
            tvStatus.setTextColor(ContextCompat.getColor(this, running ? R.color.status_running : R.color.status_stopped));
            tvPortInfo.setText("Port: " + port);
            btnStartStop.setText(running ? "Stop Proxy" : "Start Proxy");
            btnStartStop.setBackgroundTintList(ContextCompat.getColorStateList(this,
                    running ? R.color.status_stopped : R.color.accent_violet));
        });
    }

    private void refreshTrafficList() {
        String q = etSearch != null && etSearch.getText() != null
                ? etSearch.getText().toString().trim().toLowerCase() : "";
        List<TrafficEntry> all = TrafficManager.getInstance().getSessionData();
        List<TrafficEntry> filtered = new ArrayList<>();
        for (TrafficEntry e : all) {
            if (q.isEmpty()
                    || e.method.toLowerCase().contains(q)
                    || e.uri.toLowerCase().contains(q)
                    || e.hostname.toLowerCase().contains(q)
                    || String.valueOf(e.statusCode).contains(q)) {
                filtered.add(e);
            }
        }
        adapter.submit(filtered);
    }

    private void updateStats() {
        int n = TrafficManager.getInstance().size();
        tvStats.setText("Captured entries: " + n);
    }

    @Override
    public void onStatusChanged(boolean running, int port) {
        refreshStatusUi();
    }

    @Override
    public void onTraffic(TrafficEntry entry) {
        DatabaseManager.getInstance(this).insertSummary(entry);
        runOnUiThread(() -> {
            updateStats();
            if (pageTraffic.getVisibility() == View.VISIBLE) refreshTrafficList();
        });
    }

    @Override
    public void onTrafficUpdated() {
        runOnUiThread(() -> {
            updateStats();
            if (pageTraffic.getVisibility() == View.VISIBLE) refreshTrafficList();
        });
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent i = new Intent(this, ProxyForegroundService.class);
        bindService(i, connection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (bound) {
            if (proxyService != null) proxyService.setCallback(null);
            unbindService(connection);
            bound = false;
        }
    }

    @Override
    protected void onDestroy() {
        TrafficManager.getInstance().removeListener(this);
        super.onDestroy();
    }

    // Minimal text watcher
    private static class SimpleTextWatcher implements android.text.TextWatcher {
        private final java.util.function.Consumer<String> cb;
        SimpleTextWatcher(java.util.function.Consumer<String> cb) { this.cb = cb; }
        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { cb.accept(s.toString()); }
        @Override public void afterTextChanged(android.text.Editable s) {}
    }
}

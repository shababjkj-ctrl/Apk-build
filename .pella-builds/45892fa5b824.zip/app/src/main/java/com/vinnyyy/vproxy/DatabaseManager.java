package com.vinnyyy.vproxy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Optional SQLite-backed history (mirrors TrafficManager for larger persistence).
 * Bounded by MAX_ROWS.
 */
public class DatabaseManager extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseManager";
    private static final String DB_NAME = "mohasin_traffic.db";
    private static final int DB_VERSION = 1;
    private static final int MAX_ROWS = 1000;

    private static final String TABLE = "traffic";
    private static final String COL_ID = "id";
    private static final String COL_TS = "timestamp";
    private static final String COL_METHOD = "method";
    private static final String COL_URI = "uri";
    private static final String COL_STATUS = "status";
    private static final String COL_HOST = "hostname";

    private static DatabaseManager instance;

    public static synchronized DatabaseManager getInstance(Context ctx) {
        if (instance == null) {
            instance = new DatabaseManager(ctx.getApplicationContext());
        }
        return instance;
    }

    private DatabaseManager(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE + " (" +
                COL_ID + " TEXT PRIMARY KEY," +
                COL_TS + " INTEGER," +
                COL_METHOD + " TEXT," +
                COL_URI + " TEXT," +
                COL_STATUS + " INTEGER," +
                COL_HOST + " TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ts ON " + TABLE + "(" + COL_TS + " DESC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public void insertSummary(TrafficEntry e) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(COL_ID, e.id);
            cv.put(COL_TS, e.timestamp);
            cv.put(COL_METHOD, e.method);
            cv.put(COL_URI, e.uri);
            cv.put(COL_STATUS, e.statusCode);
            cv.put(COL_HOST, e.hostname);
            db.insertWithOnConflict(TABLE, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
            // prune
            db.execSQL("DELETE FROM " + TABLE + " WHERE " + COL_ID + " NOT IN (" +
                    "SELECT " + COL_ID + " FROM " + TABLE + " ORDER BY " + COL_TS + " DESC LIMIT " + MAX_ROWS + ")");
        } catch (Exception ex) {
            Log.e(TAG, "insert failed", ex);
        }
    }

    public void clear() {
        try {
            getWritableDatabase().delete(TABLE, null, null);
        } catch (Exception ex) {
            Log.e(TAG, "clear failed", ex);
        }
    }

    public int count() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE, null)) {
            if (c.moveToFirst()) return c.getInt(0);
        } catch (Exception ignored) {}
        return 0;
    }
}

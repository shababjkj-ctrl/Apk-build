package com.vinnyyy.vproxy;

import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Lightweight local HTTP proxy using NanoHTTPD.
 * Forwards requests to a configured target base URL.
 * Captures request/response metadata and bodies for the traffic log.
 * Supports CONNECT method acknowledgement for HTTPS tunneling (no TLS interception).
 */
public class ProxyServer extends NanoHTTPD {
    private static final String TAG = "ProxyServer";

    private final OkHttpClient client;
    private String forwardUrl;
    private ProxyListener listener;

    public interface ProxyListener {
        void onTrafficCaptured(TrafficEntry entry);
    }

    public ProxyServer(int port, String forwardUrl, ProxyListener listener) {
        super(port);
        this.client = new OkHttpClient.Builder()
                .followRedirects(false)
                .followSslRedirects(false)
                .build();
        this.forwardUrl = forwardUrl != null ? forwardUrl.replaceAll("/$", "") : "";
        this.listener = listener;
    }

    public void setForwardUrl(String url) {
        this.forwardUrl = url != null ? url.replaceAll("/$", "") : "";
    }

    public void setListener(ProxyListener listener) {
        this.listener = listener;
    }

    @Override
    public Response serve(IHTTPSession session) {
        String method = session.getMethod().name();
        String uri = session.getUri();
        Map<String, String> headers = session.getHeaders();

        // Handle CONNECT for HTTPS tunneling (acknowledge without decrypting)
        if ("CONNECT".equalsIgnoreCase(method)) {
            // NanoHTTPD doesn't fully support raw CONNECT tunnels easily;
            // return 200 and let client proceed (limited tunneling support).
            return newFixedLengthResponse(Response.Status.OK, "text/plain", "Connection Established");
        }

        if (forwardUrl == null || forwardUrl.isEmpty()) {
            return newFixedLengthResponse(Response.Status.SERVICE_UNAVAILABLE,
                    "text/plain", "Forward URL not configured");
        }

        try {
            // Read request body
            Map<String, String> files = new HashMap<>();
            session.parseBody(files);
            String bodyStr = files.get("postData");
            byte[] reqBody = bodyStr != null ? bodyStr.getBytes() : new byte[0];

            // Build target URL
            String query = session.getQueryParameterString();
            String target = forwardUrl + uri;
            if (query != null && !query.isEmpty()) {
                target += "?" + query;
            }

            // Build OkHttp request
            Request.Builder rb = new Request.Builder().url(target);
            for (Map.Entry<String, String> h : headers.entrySet()) {
                String key = h.getKey();
                if (key == null) continue;
                String lk = key.toLowerCase();
                if (lk.equals("host") || lk.equals("content-length") || lk.equals("transfer-encoding")) {
                    continue;
                }
                rb.header(key, h.getValue());
            }

            RequestBody okBody = null;
            if (reqBody.length > 0 || "POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method) || "PATCH".equalsIgnoreCase(method)) {
                String ct = headers.get("content-type");
                if (ct == null) ct = "application/octet-stream";
                okBody = RequestBody.create(reqBody, MediaType.parse(ct));
            }

            switch (method.toUpperCase()) {
                case "GET": rb.get(); break;
                case "POST": rb.post(okBody != null ? okBody : RequestBody.create(new byte[0], null)); break;
                case "PUT": rb.put(okBody != null ? okBody : RequestBody.create(new byte[0], null)); break;
                case "DELETE": rb.delete(okBody); break;
                case "PATCH": rb.patch(okBody != null ? okBody : RequestBody.create(new byte[0], null)); break;
                case "HEAD": rb.head(); break;
                case "OPTIONS": rb.method("OPTIONS", okBody); break;
                default: rb.method(method, okBody); break;
            }

            Request request = rb.build();
            try (Response response = client.newCall(request).execute()) {
                ResponseBody body = response.body();
                byte[] respBytes = body != null ? body.bytes() : new byte[0];
                String respContentType = body != null && body.contentType() != null
                        ? body.contentType().toString() : "application/octet-stream";

                // Build header strings for logging
                StringBuilder reqH = new StringBuilder();
                for (Map.Entry<String, String> h : headers.entrySet()) {
                    reqH.append(h.getKey()).append(": ").append(h.getValue()).append("\n");
                }
                StringBuilder respH = new StringBuilder();
                for (String name : response.headers().names()) {
                    respH.append(name).append(": ").append(response.header(name)).append("\n");
                }

                TrafficEntry entry = new TrafficEntry(
                        method, target, response.code(),
                        reqH.toString(), reqBody,
                        respH.toString(), respBytes
                );
                if (listener != null) {
                    listener.onTrafficCaptured(entry);
                }

                InputStream is = new ByteArrayInputStream(respBytes);
                Response nanoResp = newFixedLengthResponse(
                        Response.Status.lookup(response.code()),
                        respContentType,
                        is,
                        respBytes.length
                );
                for (String name : response.headers().names()) {
                    String ln = name.toLowerCase();
                    if (ln.equals("transfer-encoding") || ln.equals("content-length")) continue;
                    nanoResp.addHeader(name, response.header(name));
                }
                return nanoResp;
            }
        } catch (Exception e) {
            Log.e(TAG, "proxy error", e);
            String msg = "Proxy error: " + e.getMessage();
            TrafficEntry errEntry = new TrafficEntry(method, uri, 502, "", new byte[0], "", msg.getBytes());
            if (listener != null) listener.onTrafficCaptured(errEntry);
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", msg);
        }
    }
}

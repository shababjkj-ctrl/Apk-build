package com.vinnyyy.vproxy;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

/**
 * Represents a single captured HTTP request/response pair.
 */
public class TrafficEntry {
    public final String id;
    public final long timestamp;
    public final String method;
    public final String uri;
    public final int statusCode;
    public final String reqHeaders;
    public final byte[] reqBody;
    public final String respHeaders;
    public final byte[] respBody;
    public final String hostname;
    public final String protocol;
    public final int port;
    public final String direction;
    public final long requestSize;
    public final long responseSize;

    public TrafficEntry(String method, String uri, int statusCode,
                        String reqHeaders, byte[] reqBody,
                        String respHeaders, byte[] respBody) {
        this.id = UUID.randomUUID().toString();
        this.timestamp = System.currentTimeMillis();
        this.method = method != null ? method : "UNKNOWN";
        this.uri = uri != null ? uri : "/";
        this.statusCode = statusCode;
        this.reqHeaders = reqHeaders != null ? reqHeaders : "";
        this.reqBody = reqBody != null ? reqBody : new byte[0];
        this.respHeaders = respHeaders != null ? respHeaders : "";
        this.respBody = respBody != null ? respBody : new byte[0];
        this.requestSize = this.reqBody.length;
        this.responseSize = this.respBody.length;
        this.direction = "OUT";
        this.protocol = "HTTP";
        this.port = 80;
        // crude hostname extraction
        String host = "";
        if (this.uri.startsWith("http://") || this.uri.startsWith("https://")) {
            try {
                java.net.URI u = java.net.URI.create(this.uri);
                host = u.getHost() != null ? u.getHost() : "";
                this.port = u.getPort() > 0 ? u.getPort() : (this.uri.startsWith("https") ? 443 : 80);
            } catch (Exception ignored) {}
        }
        this.hostname = host;
    }

    public String getFormattedTime() {
        return new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date(timestamp));
    }

    public String getShortSummary() {
        return method + " " + (uri.length() > 60 ? uri.substring(0, 57) + "..." : uri) + " → " + statusCode;
    }
}

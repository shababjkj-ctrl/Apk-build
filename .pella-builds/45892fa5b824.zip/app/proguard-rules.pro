# Keep application classes
-keep class com.vinnyyy.vproxy.** { *; }

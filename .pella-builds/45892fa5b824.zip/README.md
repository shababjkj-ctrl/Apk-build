# MOHASIN PROXY — Android Studio Project

**Package:** `com.vinnyyy.vproxy`  
**App name:** MOHASIN PROXY  

This is a reconstructed Android Studio project based on the original application archive (`base.zip`).

## Features

- Local HTTP proxy (NanoHTTPD + OkHttp forwarding)
- Configurable listen port and target forward URL
- Foreground service with notification
- Live traffic capture with persistent history
- Search / filter traffic
- Protocol decoder (IPv4, IPv6, TCP, UDP, DNS, HTTP, TLS metadata — read-only)
- Export to JSON / CSV via Storage Access Framework
- Dark premium UI (navy + violet/cyan accents)
- Original package identity, icons and branding preserved where recoverable

## Open in Android Studio

1. Open the root folder `MOHASIN-Proxy-AndroidStudio` in Android Studio (Hedgehog / Iguana / newer recommended).
2. Let Gradle sync (uses AGP 8.7.2, compileSdk 35).
3. Run on a device or emulator (minSdk 24).

## Notes

- HTTPS: CONNECT is acknowledged; application data remains encrypted. No TLS interception.
- PCAP export is intentionally not faked from metadata.
- Original `base.zip` is included under `original_archive/`.

## Contact

Telegram: https://t.me/PE_MOHASIN
